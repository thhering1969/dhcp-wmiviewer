﻿// MainForm.Leases.UI.cs
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;

namespace DhcpWmiViewer
{
    public partial class MainForm : Form
    {
        


// --- Auto-appended 2 closing brace(s) to fix unmatched { ---
}}

